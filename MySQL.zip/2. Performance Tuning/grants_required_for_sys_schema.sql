GRANT PROCESS ON *.* TO `user`@`host`;
GRANT SYSTEM_VARIABLES_ADMIN_ ON *.* TO `user`@`host`;
GRANT ALL PRIVILEGES ON `sys`.* TO `user`@`host`;
GRANT SELECT, INSERT, UPDATE, DELETE, DROP ON `performance_schema`.* TO `user`@`host`;