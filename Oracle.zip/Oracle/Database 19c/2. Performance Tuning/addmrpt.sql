-- Automatic Database Diagnostics Monitor
-- TOP 튜닝 대상 목록을 제공
-- 실행 가능한 권고사항들을 제시
@?/rdbms/admin/addmrpt.sql