select *
from dict
where table_name like '%%';